/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetDetailsBeanTest contains the test cases for the methods in the  
 * AssetDetailsBean class which are the methods of getters and setters */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.bean.AssetDetailsBean;

public class AssetDetailsBeanTest {

	AssetDetailsBean assetDetails=new AssetDetailsBean();
	/************************************
	 * Test case for setAssetId()
	 * 
	 ************************************/
	@Test
	public void testSetAssetId() {
		assetDetails.setAssetId(3100);
		assertEquals(3100,assetDetails.getAssetId());
	}

	/************************************
	 * Test case for setStatus()
	 * 
	 ************************************/
	@Test
	public void testSetStatus() {
		assetDetails.setStatus("Available");;
		assertEquals("Available",assetDetails.getStatus());
	}

	/************************************
	 * Test case for setAssetDescription()
	 * 
	 ************************************/
	@Test
	public void testSetAssetDescription() {
		assetDetails.setAssetDescription("core i5");;
		assertEquals("core i5",assetDetails.getAssetDescription());
	}

	/************************************
	 * Test case for setAssetName()
	 * 
	 ************************************/
	@Test
	public void testSetAssetName() {
		assetDetails.setAssetName("Laptop");;
		assertEquals("Laptop",assetDetails.getAssetName());
	}

	/************************************
	 * Test case for setQuantity()
	 * 
	 ************************************/
	@Test
	public void testSetQuantity() {
		assetDetails.setQuantity(30);;
		assertEquals(30,assetDetails.getQuantity());
	}

}
