/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetDAOAdminTest contains the test cases for the methods in the  
 * AssetDAOAdmin which are the methods of operations that are carried out by the admin */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.exception.AMSException;
import com.capgemini.ams.service.AssetServiceAdmin;
import com.capgemini.ams.service.IAssetServiceAdmin;

public class AssetDAOAdminTest {

	IAssetServiceAdmin serviceAdmin=null;

	/************************************
	 * Test case for addAssetDetails()
	 * 
	 ************************************/
	@Test
	public void testAddAssetDetails() throws AMSException {

		AssetDetailsBean assetDetails=new AssetDetailsBean();
		serviceAdmin=new AssetServiceAdmin();
		assetDetails.setAssetName("Desktop");
		assetDetails.setAssetDescription("HP EliteDesk");
		assetDetails.setQuantity(10);
		int status=1;
		assertEquals(1,serviceAdmin.addAssetDetails(assetDetails, status));
	}

	/************************************
	 * Test case for checkAssetAvailability()
	 * 
	 ************************************/
	@Test
	public void testCheckAssetAvailability() throws AMSException {

		AssetAllocationBean assetAllocation=new AssetAllocationBean();
		assetAllocation.setAllocationId(6081);
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(3001,serviceAdmin.checkAssetAvailability(assetAllocation));
	}
	
	/************************************
	 * Test case for approveRequest()
	 * 
	 ************************************/
	@Test
	public void testApproveRequest() throws AMSException {
		
		AssetAllocationBean assetAllocation=new AssetAllocationBean();
		assetAllocation.setAllocationId(6092);
		assetAllocation.setAssetId(3041);
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(1,serviceAdmin.approveRequest(assetAllocation));
	}

	/************************************
	 * Test case for rejectRequest()
	 * 
	 ************************************/
	@Test
	public void testRejectRequest() throws AMSException {
		
		AssetAllocationBean assetAllocation=new AssetAllocationBean();
		assetAllocation.setAllocationId(6100);
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(1,serviceAdmin.rejectRequest(assetAllocation));
	}

	/************************************
	 * Test case for updateAssetName()
	 * 
	 ************************************/
	@Test
	public void testUpdateAssetName() throws AMSException {

		AssetDetailsBean assetNameDetails=new AssetDetailsBean();
		assetNameDetails.setAssetName("Laptop");
		assetNameDetails.setAssetId(2000);
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(1,serviceAdmin.updateAssetName(assetNameDetails));
	}

	/************************************
	 * Test case for updateAssetDescription()
	 * 
	 ************************************/
	@Test
	public void testUpdateAssetDescription() throws AMSException {

		AssetDetailsBean assetDescriptionDetails=new AssetDetailsBean();
		assetDescriptionDetails.setAssetDescription("core i5");
		assetDescriptionDetails.setAssetId(2000);
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(1,serviceAdmin.updateAssetDescription(assetDescriptionDetails));
	}

	/************************************
	 * Test case for updateAssetQuantity()
	 * 
	 ************************************/
	@Test
	public void testUpdateAssetQuantity() throws AMSException {

		AssetDetailsBean assetQuantityDetails=new AssetDetailsBean();
		assetQuantityDetails.setQuantity(20);
		assetQuantityDetails.setAssetId(2000);
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(1,serviceAdmin.updateAssetQuantity(assetQuantityDetails));
	}
	
	/************************************
	 * Test case for updateAssetStatus()
	 * 
	 ************************************/
	@Test
	public void testUpdateAssetStatus() throws AMSException {
		
		int newAssetStatus=1;
		int assetId=2000;
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(1,serviceAdmin.updateAssetStatus(assetId, newAssetStatus));
	}

}
