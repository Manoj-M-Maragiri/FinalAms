/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetServiceAdminTest contains the test cases for the methods in the  
 * AssetServiceAdmin which are the methods which performs validation of the input entered by admin */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.service.AssetServiceAdmin;
import com.capgemini.ams.service.AssetServiceUser;
import com.capgemini.ams.service.IAssetServiceAdmin;
import com.capgemini.ams.service.IAssetServiceUser;

public class AssetServiceAdminTest {

	IAssetServiceAdmin serviceAdmin=null;
	
	/************************************
	 * Test case for isValidAssetName()
	 * 
	 ************************************/

	@Test
	public void testIsValidAssetName() {
		
		serviceAdmin=new AssetServiceAdmin();
		assertEquals(true, serviceAdmin.isValidAssetName("Laptop"));
	}

	/************************************
	 * Test case for isValidString()
	 * 
	 ************************************/

	@Test
	public void testIsValidString() {

		serviceAdmin=new AssetServiceAdmin();
		assertEquals(true, serviceAdmin.isValidString("core i5"));
	}

}
