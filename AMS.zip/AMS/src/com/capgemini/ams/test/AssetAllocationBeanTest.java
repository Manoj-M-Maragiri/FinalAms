/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetAllocationBeanTest contains the test cases for the methods in the  
 * AssetAllocationBean class which are the methods of getters and setters */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.bean.AssetAllocationBean;

public class AssetAllocationBeanTest {

	AssetAllocationBean assetAllocation= new AssetAllocationBean();
	/************************************
	 * Test case for setAllocationId()
	 * 
	 ************************************/
	@Test
	public void testSetAllocationId() {
		assetAllocation.setAllocationId(6046);
		assertEquals(6046,assetAllocation.getAllocationId());
	}

	/************************************
	 * Test case for setAssetId()
	 * 
	 ************************************/
	@Test
	public void testSetAssetId() {
		assetAllocation.setAssetId(3002);;
		assertEquals(3002,assetAllocation.getAssetId());
	}

	/************************************
	 * Test case for setEmpNo()
	 * 
	 ************************************/
	@Test
	public void testSetEmpNo() {
		assetAllocation.setEmpNo(10025);;
		assertEquals(10025,assetAllocation.getEmpNo());
	}
	
	/************************************
	 * Test case for setAllocationDate()
	 * 
	 ************************************/
	@Test
	public void testSetAllocationDate() {
		assetAllocation.setAllocationDate("26-08-2018");;
		assertEquals("26-08-2018",assetAllocation.getAllocationDate());
	}

	/************************************
	 * Test case for setReleaseDate()
	 * 
	 ************************************/
	@Test
	public void testSetReleaseDate() {
		assetAllocation.setReleaseDate("26-08-2018");;
		assertEquals("26-08-2018",assetAllocation.getReleaseDate());
	}

	/************************************
	 * Test case for setAssetStatus()
	 * 
	 ************************************/
	@Test
	public void testSetAssetStatus() {
		assetAllocation.setAssetStatus("Approved");;
		assertEquals("Approved",assetAllocation.getAssetStatus());
	}

}
