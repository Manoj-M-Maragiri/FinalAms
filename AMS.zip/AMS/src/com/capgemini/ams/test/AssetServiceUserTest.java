/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetServiceUserTest contains the test cases for the methods in the  
 * AssetServiceUser which are the methods of validation */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;
import com.capgemini.ams.service.AssetServiceUser;
import com.capgemini.ams.service.IAssetServiceUser;

public class AssetServiceUserTest {


	IAssetServiceUser serviceUser=null;
	
	/************************************
	 * Test case for isValidUserId()
	 * 
	 ************************************/
	@Test
	public void testIsValidUserId() {

		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidUserId("180010"));
	}

	/************************************
	 * Test case for isValidAssetId()
	 * 
	 ************************************/
	@Test
	public void testIsValidAssetId() {
		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidAssetId("3000"));
	}

	/************************************
	 * Test case for isValidEmployeeId()
	 * 
	 ************************************/
	@Test
	public void testIsValidEmployeeId() {
		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidEmployeeId("180023"));
	}

	/************************************
	 * Test case for isValidRequisitionId()
	 * 
	 ************************************/
	@Test
	public void testIsValidRequisitionId() {
		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidRequisitionId("6086"));
	}

	/************************************
	 * Test case for isValidQuantity()
	 * 
	 ************************************/
	@Test
	public void testIsValidQuantity() {
		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidQuantity("30"));
	}

	/************************************
	 * Test case for isValidOption()
	 * 
	 ************************************/
	@Test
	public void testIsValidOption() {
		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidOption("2"));
	}

	/************************************
	 * Test case for isValidPassword()
	 * 
	 ************************************/
	@Test
	public void testIsValidPassword() {
		serviceUser=new AssetServiceUser();
		assertEquals(true, serviceUser.isValidPassword("abcdA9!"));
	}

}
