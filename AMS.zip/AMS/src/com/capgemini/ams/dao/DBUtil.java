/***********************************Author Name:Manoj M Maragiri******Emp Id : 155246******************************************/
/*The DBUtil class contains a method that is required to establish Connection with the Database
 * Firstly, it registers the driver and then with the help of DriverManager the connection to
 * the database is made.
*/
package com.capgemini.ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.capgemini.ams.exception.AMSException;
import com.capgemini.ams.dao.IQueryMapper;


public class DBUtil {
	private static Connection connection = null;

	public static Connection establishConnection() throws SQLException {
		
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg210","training210");
			return connection;
		
	}
}