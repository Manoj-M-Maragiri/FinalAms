/***********************************Author Name:Manoj M Maragiri******Emp Id : 155246******************************************/
/*The AssetAllocationBean is a bean class that contains the getters and setters 
 * and constructors with parameters and constructors without paramaters
*/
package com.capgemini.ams.bean;

public class AssetAllocationBean {

	private int allocationId;
	private int assetId;
	private int empNo;
	private String allocationDate;
	private String releaseDate;
	private String assetStatus;
	
	public int getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}
	
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getAllocationDate() {
		return allocationDate;
	}
	public void setAllocationDate(String allocationDate) {
		this.allocationDate = allocationDate;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getAssetStatus() {
		return assetStatus;
	}
	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}
	public AssetAllocationBean(){
		
	}
	public AssetAllocationBean( int assetId, int empNo){
		this.assetId = assetId;
		this.empNo = empNo;
	}
	public AssetAllocationBean(int allocationId, int assetId, int empNo,
			String allocationDate, String releaseDate) {
		super();
		this.allocationId = allocationId;
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
	}
	
}
