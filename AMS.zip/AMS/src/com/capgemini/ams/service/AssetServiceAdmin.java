/***********************************Author Name:Manoj M Maragiri*********Emp Id : 155246******************************************/
/*The AssetServiceAdmin contains the implementation of the methods that are being used by the Admin
 *and performs the required operations that are needed by the Admin. It also contains the 
 *validations of the input taken from the Admin.
*/

package com.capgemini.ams.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.dao.AssetDAOAdmin;
import com.capgemini.ams.dao.IAssetDAOAdmin;
import com.capgemini.ams.exception.AMSException;

public class AssetServiceAdmin implements IAssetServiceAdmin {

	IAssetDAOAdmin assetdaoAdmin=null;
	
	//addAssetDetails is a method to add asset to the inventory
	public int addAssetDetails(AssetDetailsBean assetDetails,int status) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.addAssetDetails(assetDetails,status);
	}


	//assetInInventory is a method to display the asset to the inventory using ArrayList of generic type AssetDetailsBean
	public ArrayList<AssetDetailsBean> assetInInventory() throws AMSException{
	
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.assetInInventory();
	}
	
	
	//updateAssetName is a method to update asset name to the inventory which takes an object assetNameDetails as an argument
	public int updateAssetName(AssetDetailsBean assetNameDetails) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetName(assetNameDetails);
	}
	
	
	//updateAssetDescription is a method to update asset description in the inventory which takes an object assetNameDetails as an argument
	public int updateAssetDescription(AssetDetailsBean assetDescriptionDetails) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetDescription(assetDescriptionDetails);
	}
	
	
	//updateAssetQuantity is a method to update asset quantity to the inventory which takes an object assetNameDetails as an argument
	public int updateAssetQuantity(AssetDetailsBean assetQuantityDetails) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetQuantity(assetQuantityDetails);
	}

	
	//updateAssetStatus is a method to update asset status to the inventory which takes assetId and newAssetStatus as an argument
	public int updateAssetStatus(int assetId,int newAssetStatus) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetStatus(assetId,newAssetStatus);
	}
	
	
	//checkAssetAvailability is a method to check whether asset is available in the inventory which takes an object as an argument
	public int checkAssetAvailability(AssetAllocationBean assetAllocation)throws AMSException {
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.checkAssetAvailability(assetAllocation);
	}
	
	
	//Method to approve request which takes an object as an argument
	public int approveRequest(AssetAllocationBean assetAllocation)throws AMSException {
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.approveRequest(assetAllocation);
	}
	
	
	//Method to reject request which takes an object as an argument
	public int rejectRequest(AssetAllocationBean assetAllocation)throws AMSException {
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.rejectRequest(assetAllocation);
	}
	
	
	public ArrayList<AssetAllocationBean> displayAllocatedAssets() throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.displayAllocatedAssets();
	}
	
	
	public ArrayList<AssetAllocationBean> displayUnallocatedAssets() throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.displayUnallocatedAssets();
	}


	public ArrayList<AssetAllocationBean> displayUnapprovedAssets() throws AMSException {

		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.displayUnapprovedAssets();
	}

	
	//method to validate asset name
	public boolean isValidAssetName(String assetName) {
		Pattern pattern = Pattern.compile("[A-Za-z0-9 ,()/?&!@#$-_]{3,25}");
		Matcher matcher = pattern.matcher(assetName);
		return matcher.matches();
	}

	
	//method to validate description of an asset
	public boolean isValidString(String string) {
		Pattern pattern = Pattern.compile("[A-Za-z0-9 ,()/?&!@#$%*+-_]{5,25}");
		Matcher matcher = pattern.matcher(string);
		return matcher.matches();
	}


}
