package com.cg.recharge.service;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.dao.IRechargeDao;
import com.cg.recharge.dao.RechargeDaoImplementation;
import com.cg.recharge.exception.RechargeProblemException;

public class RechargeServiceImplementation implements IRechargeService{
	
	IRechargeDao rechargeDao=null;
	public int addRechargeDetails(RechargeBean recharge) throws RechargeProblemException{
		
		rechargeDao=new RechargeDaoImplementation();
		
		return rechargeDao.addRechargeDetails(recharge);
	}

}
