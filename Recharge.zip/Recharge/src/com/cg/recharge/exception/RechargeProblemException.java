package com.cg.recharge.exception;

public class RechargeProblemException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RechargeProblemException(String message){
		
		super(message);
	}
	
}
