package com.cg.recharge.bean;

import java.time.LocalDate;

public class RechargeBean {
	
	private String customerName;
	private Long mobile;
	private int amount;
	private String planName;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public RechargeBean(){
		
	}
	
	public RechargeBean(String customerName, Long mobile, int amount,
			String planName,int rid) {
		this.customerName = customerName;
		this.mobile = mobile;
		this.amount = amount;
		this.planName = planName;
	}
	
	public String toString(){
		return customerName+" "+mobile+" "+amount+" "+planName;
		
	}
	
}
