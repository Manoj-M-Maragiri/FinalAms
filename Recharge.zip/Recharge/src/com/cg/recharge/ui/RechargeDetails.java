package com.cg.recharge.ui;

import java.util.Scanner;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.exception.RechargeProblemException;
import com.cg.recharge.service.IRechargeService;
import com.cg.recharge.service.RechargeServiceImplementation;
import org.apache.log4j.*;

public class RechargeDetails {

	public static void main(String[] args) {
		Logger logger=Logger.getRootLogger();
		System.out.println("---Recharge Details---");
		System.out.println();
		System.out.println("1.Recharge Number");
		System.out.println("2.View Recharge Details");
		System.out.println("Enter your Option");
		Scanner scanner=new Scanner(System.in);
		int option=scanner.nextInt();
		switch(option)
		{
		case 1:
			System.out.println("Enter Customer Name");
			String customerName=scanner.next();
			System.out.println("Enter mobile Number");
			Long mobile=scanner.nextLong();
			System.out.println("Enter the amount");
			int amount=scanner.nextInt();
			System.out.println("Enter Plan Name");
			System.out.println("1.rc99");
			System.out.println("2.rc200");
			System.out.println("3.rc399");
			String planName=scanner.next();
			
			RechargeBean recharge=new RechargeBean();
			recharge.setCustomerName(customerName);
			recharge.setMobile(mobile);
			recharge.setAmount(amount);
			recharge.setPlanName(planName);
			
			
			int status=0;
			try {
				status = new RechargeDetails().addRecharge(recharge);
					System.out.println("Your Mobile number "+mobile+" is Recharged with Plan "+planName+" and Recharge Id: "+status);
			} catch (RechargeProblemException e) {
				System.err.println("exception: "+e.getMessage());
			}
			break;
		case 2:
			break;
		default:
			break;
		}
		scanner.close();
	}
	IRechargeService service=null;
	public int addRecharge(RechargeBean recharge) throws RechargeProblemException{
		service=new RechargeServiceImplementation();
		return service.addRechargeDetails(recharge);
		
		
	}

}
