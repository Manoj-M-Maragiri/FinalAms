package com.cg.recharge.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	static Connection conn=null;
public static Connection estabblishConnection() throws SQLException{
		
		conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg210","training210");
		
		return conn;
	}
	
}
