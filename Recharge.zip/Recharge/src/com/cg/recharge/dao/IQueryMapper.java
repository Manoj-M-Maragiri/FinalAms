package com.cg.recharge.dao;

public interface IQueryMapper {

	public static final String INSERT_QUERY="INSERT INTO RECHARGEDETAILS1 VALUES(rechargeid_seq.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String IDVALUE="SELECT rechargeid_seq.currval FROM DUAL";
}
