package com.cg.recharge.dao;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.exception.RechargeProblemException;

public interface IRechargeDao {

	public abstract int addRechargeDetails(RechargeBean recharge) throws RechargeProblemException ;
}
