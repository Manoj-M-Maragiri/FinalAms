package com.cg.recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.dbutil.DBUtil;
import com.cg.recharge.exception.RechargeProblemException;

public class RechargeDaoImplementation implements IRechargeDao{
	
	private Connection conn=null;
	public int addRechargeDetails(RechargeBean recharge) throws RechargeProblemException{
		int status = 0;
		try {
			conn=DBUtil.estabblishConnection();
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, recharge.getCustomerName());
			preparedStatement.setLong(2, recharge.getMobile());
			preparedStatement.setInt(3, recharge.getAmount());
			preparedStatement.setString(4, recharge.getPlanName());
			int storedStatus=preparedStatement.executeUpdate();
			
			
			if(storedStatus==1){
				PreparedStatement preparedstatement=conn.prepareStatement(IQueryMapper.IDVALUE);
				ResultSet rs=preparedstatement.executeQuery();
				rs.next();
				status=rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new RechargeProblemException("problem:"+e.getMessage());
		}
		return status;
		
	}

}
