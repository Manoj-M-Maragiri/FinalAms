package com.cg.recharge.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class RechargeDetailsTest {

	@Test
	public void testAddRecharge() {
		fail("Not yet implemented");
	}

}
