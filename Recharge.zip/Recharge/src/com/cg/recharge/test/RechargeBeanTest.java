package com.cg.recharge.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.recharge.bean.RechargeBean;

public class RechargeBeanTest {
	RechargeBean recharge=new RechargeBean();
	@Test
	public void testGetCustomerName() {
		recharge.setCustomerName("Akhil");
		assertEquals("Akhil",recharge.getCustomerName());
	}

	@Test
	public void testGetMobile() {
		recharge.setMobile((long)9874563215L);
		assertEquals((long)9874563215L, (long)recharge.getMobile());
	}

	@Test
	public void testGetAmount() {
		recharge.setAmount(200);
		assertEquals(200, recharge.getAmount());
	}

	@Test
	public void testGetPlanName() {
		recharge.setPlanName("rc200");
		assertEquals("rc200",recharge.getPlanName());
	}

}
